import React  from 'react';
import { Text, View, StyleSheet,FlatList, TouchableOpacity } from 'react-native';

export default function TodoItem({item, pressHandler}){
  return(
    <TouchableOpacity onPress={()=> pressHandler(item.key) }>
    <Text style={styles.text}> {item.text}</Text>
    </TouchableOpacity>
  )
}

const styles=StyleSheet.create({
  text:{
    padding:16,
    margin:16, 
    borderRadius:10,
    borderColor:'black',
    borderWidth:2,
    borderStyle:'dashed',
    textAlign:'left'
  }
} )